/*! Copyright (c) 2011 Piotr Rochala (http://rocha.la)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * Version: 1.3.2
 *
 */
!
function (e) {
    jQuery.fn.extend({
        slimScroll: function (i) {
            var o = {
                width: "auto",
                height: "250px",
                size: "7px",
                color: "#000",
                position: "right",
                distance: "1px",
                start: "top",
                opacity: .4,
                alwaysVisible: !1,
                disableFadeOut: !1,
                railVisible: !1,
                railColor: "#333",
                railOpacity: .2,
                railDraggable: !0,
                railClass: "slimScrollRail",
                barClass: "slimScrollBar",
                wrapperClass: "slimScrollDiv",
                allowPageScroll: !1,
                wheelStep: 20,
                touchScrollStep: 200,
                borderRadius: "7px",
                railBorderRadius: "7px",
                animate: !0
            },
                a = e.extend(o, i);
            return this.each(function () {
                function o(t) {
                    if (u) {
                        var t = t || window.event,
                            i = 0;
                        t.wheelDelta && (i = -t.wheelDelta / 120), t.detail && (i = t.detail / 3);
                        var o = t.target || t.srcTarget || t.srcElement;
                        e(o).closest("." + a.wrapperClass).is(S.parent()) && r(i, !0), t.preventDefault && !y && t.preventDefault(), y || (t.returnValue = !1)
                    }
                }
                function r(e, t, i) {
                    y = !1;
                    var o = e,
                        r = S.outerHeight() - M.outerHeight();
                    if (t && (o = parseInt(M.css("top")) + e * parseInt(a.wheelStep) / 100 * M.outerHeight(), o = Math.min(Math.max(o, 0), r), o = e > 0 ? Math.ceil(o) : Math.floor(o), M.css({
                        top: o + "px"
                    })), v = parseInt(M.css("top")) / (S.outerHeight() - M.outerHeight()), o = v * (S[0].scrollHeight - S.outerHeight()), i) {
                        o = e;
                        var s = o / S[0].scrollHeight * S.outerHeight();
                        s = Math.min(Math.max(s, 0), r), M.css({
                            top: s + "px"
                        })
                    }
                    "scrollTo" in a && a.animate ? S.animate({
                        scrollTop: o
                    }) : S.scrollTop(o), S.trigger("slimscrolling", ~~o), l(), c()
                }
                function s() {
                    window.addEventListener ? (this.addEventListener("DOMMouseScroll", o, !1), this.addEventListener("mousewheel", o, !1)) : document.attachEvent("onmousewheel", o)
                }
                function n() {
                    f = Math.max(S.outerHeight() / S[0].scrollHeight * S.outerHeight(), m), M.css({
                        height: f + "px"
                    });
                    var e = f == S.outerHeight() ? "none" : "block";
                    M.css({
                        display: e
                    })
                }
                function l() {
                    if (n(), clearTimeout(p), v == ~~v) {
                        if (y = a.allowPageScroll, b != v) {
                            var e = 0 == ~~v ? "top" : "bottom";
                            S.trigger("slimscroll", e)
                        }
                    } else y = !1;
                    return b = v, f >= S.outerHeight() ? void(y = !0) : (M.stop(!0, !0).fadeIn("fast"), void(a.railVisible && H.stop(!0, !0).fadeIn("fast")))
                }
                function c() {
                    a.alwaysVisible || (p = setTimeout(function () {
                        a.disableFadeOut && u || h || d || (M.fadeOut("slow"), H.fadeOut("slow"))
                    }, 1e3))
                }
                var u, h, d, p, g, f, v, b, w = "<div></div>",
                    m = 30,
                    y = !1,
                    S = e(this);
                if ("ontouchstart" in window && window.navigator.msPointerEnabled && S.css("-ms-touch-action", "none"), S.parent().hasClass(a.wrapperClass)) {
                    var E = S.scrollTop();
                    if (M = S.parent().find("." + a.barClass), H = S.parent().find("." + a.railClass), n(), e.isPlainObject(i)) {
                        if ("height" in i && "auto" == i.height) {
                            S.parent().css("height", "auto"), S.css("height", "auto");
                            var x = S.parent().parent().height();
                            S.parent().css("height", x), S.css("height", x)
                        }
                        if ("scrollTo" in i) E = parseInt(a.scrollTo);
                        else if ("scrollBy" in i) E += parseInt(a.scrollBy);
                        else if ("destroy" in i) return M.remove(), H.remove(), void S.unwrap();
                        r(E, !1, !0)
                    }
                } else {
                    a.height = "auto" == i.height ? S.parent().height() : i.height;
                    var C = e(w).addClass(a.wrapperClass).css({
                        position: "relative",
                        overflow: "hidden",
                        width: a.width,
                        height: a.height
                    });
                    S.css({
                        overflow: "hidden",
                        width: a.width,
                        height: a.height
                    });
                    var H = e(w).addClass(a.railClass).css({
                        width: a.size,
                        height: "100%",
                        position: "absolute",
                        top: 0,
                        display: a.alwaysVisible && a.railVisible ? "block" : "none",
                        "border-radius": a.railBorderRadius,
                        background: a.railColor,
                        opacity: a.railOpacity,
                        zIndex: 90
                    }),
                        M = e(w).addClass(a.barClass).css({
                            background: a.color,
                            width: a.size,
                            position: "absolute",
                            top: 0,
                            opacity: a.opacity,
                            display: a.alwaysVisible ? "block" : "none",
                            "border-radius": a.borderRadius,
                            BorderRadius: a.borderRadius,
                            MozBorderRadius: a.borderRadius,
                            WebkitBorderRadius: a.borderRadius,
                            zIndex: 99
                        }),
                        D = "right" == a.position ? {
                            right: a.distance
                        } : {
                            left: a.distance
                        };
                    H.css(D), M.css(D), S.wrap(C), S.parent().append(M), S.parent().append(H), a.railDraggable && M.bind("mousedown", function (i) {
                        var o = e(document);
                        return d = !0, t = parseFloat(M.css("top")), pageY = i.pageY, o.bind("mousemove.slimscroll", function (e) {
                            currTop = t + e.pageY - pageY, M.css("top", currTop), r(0, M.position().top, !1)
                        }), o.bind("mouseup.slimscroll", function () {
                            d = !1, c(), o.unbind(".slimscroll")
                        }), !1
                    }).bind("selectstart.slimscroll", function (e) {
                        return e.stopPropagation(), e.preventDefault(), !1
                    }), "ontouchstart" in window && window.navigator.msPointerEnabled && (S.bind("MSPointerDown", function (e) {
                        g = e.originalEvent.pageY
                    }), S.bind("MSPointerMove", function (e) {
                        e.originalEvent.preventDefault();
                        var t = (g - e.originalEvent.pageY) / a.touchScrollStep;
                        r(t, !0), g = e.originalEvent.pageY
                    })), H.hover(function () {
                        l()
                    }, function () {
                        c()
                    }), M.hover(function () {
                        h = !0
                    }, function () {
                        h = !1
                    }), S.hover(function () {
                        u = !0, l(), c()
                    }, function () {
                        u = !1, c()
                    }), S.bind("touchstart", function (e) {
                        e.originalEvent.touches.length && (g = e.originalEvent.touches[0].pageY)
                    }), S.bind("touchmove", function (e) {
                        if (y || e.originalEvent.preventDefault(), e.originalEvent.touches.length) {
                            var t = (g - e.originalEvent.touches[0].pageY) / a.touchScrollStep;
                            r(t, !0), g = e.originalEvent.touches[0].pageY
                        }
                    }), n(), "bottom" === a.start ? (M.css({
                        top: S.outerHeight() - M.outerHeight()
                    }), r(0, !0)) : "top" !== a.start && (r(e(a.start).position().top, null, !0), a.alwaysVisible || M.hide()), s()
                }
            }), this
        }
    }), jQuery.fn.extend({
        slimscroll: jQuery.fn.slimScroll
    })
}(jQuery);